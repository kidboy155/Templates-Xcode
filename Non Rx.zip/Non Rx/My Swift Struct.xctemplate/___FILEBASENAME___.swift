//___FILEHEADER___

import Foundation

struct ___FILEBASENAMEASIDENTIFIER___ {
}
