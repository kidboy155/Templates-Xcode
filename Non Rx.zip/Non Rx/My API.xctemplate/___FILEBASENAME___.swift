//___FILEHEADER___

import UIKit

class ___FILEBASENAMEASIDENTIFIER___: API {
    typealias T = <#TypeReponse#>

    // path of the ___FILEBASENAMEASIDENTIFIER___ api
    var path: String = <#path#>
    // method of the ___FILEBASENAMEASIDENTIFIER___ api
    var method: HTTPMethod { return .get }
    // parameters of the ___FILEBASENAMEASIDENTIFIER___ api
    var parameters: Parameters? {
        return [<#parameters#>
        ]
    }
    // encoding of the ___FILEBASENAMEASIDENTIFIER___ api
    var encoding: ParameterEncoding { return URLEncoding.default }
    // parser result of ___FILEBASENAMEASIDENTIFIER___ api
    
    // call request of api ___FILEBASENAMEASIDENTIFIER___
}
