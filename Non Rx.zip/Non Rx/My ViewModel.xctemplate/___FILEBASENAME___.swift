//___FILEHEADER___

import UIKit

class ___FILEBASENAMEASIDENTIFIER___: BaseViewModel {
    var repos: <#Repos#>!
    // MARK: - 入力
    
    // MARK: - 出力
    var errorMessage = Binding<String?>(value: nil)
    var <#isSuccessful#> = Binding<Bool>(value: false)
    init(repos: <#Repos#>) {
        super.init()
        self.repos = repos
    }
    
    //MARK: - リクエスト機能
}
