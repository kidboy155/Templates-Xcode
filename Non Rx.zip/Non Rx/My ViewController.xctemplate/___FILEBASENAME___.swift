//___FILEHEADER___

import UIKit

class ___FILEBASENAMEASIDENTIFIER___: BaseViewController {
    var viewModel: <#ViewModel#>!
    //MARK: - ライフ　サイクル
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configUI()
        bindingData()
    }
}

//MARK: - プライベートメソッド

extension ___FILEBASENAMEASIDENTIFIER___ {
    fileprivate func configUI() {
        <#configure UI view#>
    }
    // ビューモデル間でデータをビューにバインドする
    fileprivate func bindingData(){
        viewModel.isLoadingData.bind { [weak self]  in self?.isLoadingData.value = $0 }
        viewModel.errorMessage.bind{ [unowned self]  in if let message = $0, !message.isEmpty {self.showLoginError(message: message)} }
        viewModel.<#isSuccessful#>.bind { [unowned self]  in
            if $0 { <#process with case successful#> }
        }
    }
}
//MARK: - プライベートメソッド

extension ___FILEBASENAMEASIDENTIFIER___ {
    
}
